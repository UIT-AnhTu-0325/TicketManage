export const CREATE = 'CREATE';
export const GET_ALL = 'GET_ALL';
export const GET_BY_ID = 'GET_BY_ID';